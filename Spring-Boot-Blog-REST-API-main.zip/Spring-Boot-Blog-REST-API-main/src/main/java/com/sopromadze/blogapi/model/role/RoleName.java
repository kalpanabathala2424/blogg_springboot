package com.sopromadze.blogapi.model.role;

public enum RoleName {
	ROLE_ADMIN,
	ROLE_USER,
}
